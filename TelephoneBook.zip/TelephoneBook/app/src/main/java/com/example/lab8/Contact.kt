package com.example.lab8

// 聯絡人資料結構
data class Contact(
    val name: String,
    val phone: String,
    val email: String
)
