
package com.example.foodorderingwizard

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.commit

class MainActivity : AppCompatActivity() {

    private val vm: OrderViewModel by viewModels()
    private val pager = WizardPagerAdapter()

    private lateinit var home: View
    private lateinit var fragmentContainer: FrameLayout
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Create the main screen and fragment area
        val root = FrameLayout(this)
        root.id = View.generateViewId()

        home = layoutInflater.inflate(
            R.layout.activity_main,
            root,
            false
        )

        fragmentContainer = FrameLayout(this).apply {
            id = R.id.fragment_container
            visibility = View.GONE
        }

        root.addView(home)
        root.addView(
            fragmentContainer,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        setContentView(root)

        summary = home.findViewById(
            R.id.tvOrderSummary
        )

        home.findViewById<Button>(
            R.id.btnMainMeal
        ).setOnClickListener {
            openPage(0)
        }

        home.findViewById<Button>(
            R.id.btnSideDishes
        ).setOnClickListener {
            openPage(1)
        }

        home.findViewById<Button>(
            R.id.btnDrink
        ).setOnClickListener {
            openPage(2)
        }

        home.findViewById<Button>(
            R.id.btnOrder
        ).setOnClickListener {
            openPage(3)
        }

        supportFragmentManager
            .addOnBackStackChangedListener {
                updateScreen()
            }

        updateScreen()
    }

    private fun openPage(page: Int) {
        fragmentContainer.visibility = View.VISIBLE
        home.visibility = View.GONE

        supportFragmentManager.commit {
            replace(
                R.id.fragment_container,
                pager.createPage(page)
            )
            addToBackStack(null)
        }
    }

    private fun updateScreen() {
        val onHome = supportFragmentManager
            .backStackEntryCount == 0

        home.visibility =
            if (onHome) View.VISIBLE else View.GONE

        fragmentContainer.visibility =
            if (onHome) View.GONE else View.VISIBLE

        if (onHome) {
            updateSummary()
        }
    }

    private fun updateSummary() {
        val order = vm.order

        val main = order.mainMeal.ifEmpty { "-" }

        val sides = order.sideDishes
            .joinToString(", ")
            .ifEmpty { "-" }

        val drink = order.drink.ifEmpty { "-" }

        val title = if (vm.submitted) {
            "Submitted Order:"
        } else {
            "Current Selection:"
        }

        summary.text = """
            $title
            Main: $main
            Sides: $sides
            Drink: $drink
        """.trimIndent()
    }
}
