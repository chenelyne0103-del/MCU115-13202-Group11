
package com.example.foodorderingwizard

import androidx.fragment.app.Fragment

class WizardPagerAdapter {

    fun createPage(page: Int): Fragment {
        return when (page) {
            0 -> MainMealFragment()
            1 -> SideDishesFragment()
            2 -> DrinkFragment()
            3 -> ConfirmFragment()
            else -> throw IllegalArgumentException(
                "Unknown page: $page"
            )
        }
    }
}
