
package com.example.foodorderingwizard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels

class ConfirmFragment : Fragment() {

    private val vm: OrderViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(
            R.layout.fragment_confirm,
            container,
            false
        )
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        val order = vm.order

        val sides = order.sideDishes
            .joinToString(", ")
            .ifEmpty { "-" }

        val summary = """
            Main: ${order.mainMeal.ifEmpty { "-" }}
            Sides: $sides
            Drink: ${order.drink.ifEmpty { "-" }}
        """.trimIndent()

        view.findViewById<TextView>(
            R.id.tvConfirmSummary
        ).text = summary

        view.findViewById<Button>(
            R.id.btnConfirm
        ).setOnClickListener {

            if (!order.isComplete()) {
                Toast.makeText(
                    requireContext(),
                    "Please select a main meal, at least one side dish, and a drink.",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }

            AlertDialog.Builder(requireContext())
                .setTitle("Submit Order")
                .setMessage(
                    "Main: ${order.mainMeal}\n" +
                            "Sides: ${order.sideDishes.joinToString(", ")}\n" +
                            "Drink: ${order.drink}\n\n" +
                            "Submit this order?"
                )
                .setPositiveButton("Submit") { _, _ ->

                    vm.submitted = true

                    Toast.makeText(
                        requireContext(),
                        "Order submitted! 🎉",
                        Toast.LENGTH_SHORT
                    ).show()

                    parentFragmentManager.popBackStack()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
}
