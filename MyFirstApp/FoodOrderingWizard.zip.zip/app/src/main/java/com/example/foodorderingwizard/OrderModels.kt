package com.example.foodorderingwizard




data class Order(
    var mainMeal: String = "",
    var sideDishes: List<String> = emptyList(),
    var drink: String = ""
) {
    fun isComplete(): Boolean {
        return mainMeal.isNotEmpty() &&
                sideDishes.isNotEmpty() &&
                drink.isNotEmpty()
    }
}
