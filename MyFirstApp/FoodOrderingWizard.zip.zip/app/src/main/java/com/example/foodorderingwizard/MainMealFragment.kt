
package com.example.foodorderingwizard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioGroup
import androidx.fragment.app.Fragment
import androidx.activity.viewModels
import androidx.fragment.app.activityViewModels

class MainMealFragment : Fragment() {

    private val vm: OrderViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(
            R.layout.fragment_main_meal,
            container,
            false
        )
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        val group = view.findViewById<RadioGroup>(
            R.id.rgMainMeal
        )

        val choices = mapOf(
            R.id.rbBurger to "Burger",
            R.id.rbChicken to "Fried Chicken",
            R.id.rbNuggets to "Chicken Nuggets"
        )

        val previous = choices.entries
            .firstOrNull { it.value == vm.order.mainMeal }

        previous?.let { group.check(it.key) }

        view.findViewById<Button>(
            R.id.btnDone
        ).setOnClickListener {

            vm.order.mainMeal =
                choices[group.checkedRadioButtonId] ?: ""

            parentFragmentManager.popBackStack()
        }
    }
}
