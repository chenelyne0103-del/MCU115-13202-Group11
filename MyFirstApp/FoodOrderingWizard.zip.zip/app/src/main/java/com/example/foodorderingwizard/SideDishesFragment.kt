
package com.example.foodorderingwizard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels

class SideDishesFragment : Fragment() {

    private val vm: OrderViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(
            R.layout.fragment_side_dishes,
            container,
            false
        )
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        val fries = view.findViewById<CheckBox>(R.id.cbFries)
        val salad = view.findViewById<CheckBox>(R.id.cbSalad)
        val corn = view.findViewById<CheckBox>(R.id.cbCorn)

        fries.isChecked = "Fries" in vm.order.sideDishes
        salad.isChecked = "Salad" in vm.order.sideDishes
        corn.isChecked = "Corn Cup" in vm.order.sideDishes

        view.findViewById<Button>(
            R.id.btnDone
        ).setOnClickListener {

            val selected = mutableListOf<String>()

            if (fries.isChecked) selected.add("Fries")
            if (salad.isChecked) selected.add("Salad")
            if (corn.isChecked) selected.add("Corn Cup")

            vm.order.sideDishes = selected

            parentFragmentManager.popBackStack()
        }
    }
}
