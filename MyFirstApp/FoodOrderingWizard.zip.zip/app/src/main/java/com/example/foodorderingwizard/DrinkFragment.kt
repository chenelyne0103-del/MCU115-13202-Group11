
package com.example.foodorderingwizard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels

class DrinkFragment : Fragment() {

    private val vm: OrderViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(
            R.layout.fragment_drink,
            container,
            false
        )
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        val group = view.findViewById<RadioGroup>(
            R.id.rgDrink
        )

        val choices = mapOf(
            R.id.rbCola to "Cola",
            R.id.rbTea to "Iced Tea",
            R.id.rbWater to "Water"
        )

        val previous = choices.entries
            .firstOrNull { it.value == vm.order.drink }

        previous?.let { group.check(it.key) }

        view.findViewById<Button>(
            R.id.btnDone
        ).setOnClickListener {

            vm.order.drink =
                choices[group.checkedRadioButtonId] ?: ""

            parentFragmentManager.popBackStack()
        }
    }
}
