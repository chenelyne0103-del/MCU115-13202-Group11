


package com.example.foodorderingwizard

import androidx.lifecycle.ViewModel

class OrderViewModel : ViewModel() {
    val order = Order()
    var submitted = false
}
